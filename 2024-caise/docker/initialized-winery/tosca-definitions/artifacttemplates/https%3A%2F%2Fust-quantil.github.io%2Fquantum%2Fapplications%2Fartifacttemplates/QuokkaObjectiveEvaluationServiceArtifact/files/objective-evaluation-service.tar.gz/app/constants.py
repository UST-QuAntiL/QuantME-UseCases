# Cost Functions
TSP = "tsp"
MAX_CUT = "max-cut"

# Objective Functions
EXPECTATION = "expectation"
CVAR = "cvar"
GIBBS = "gibbs"
